tdgigevsrc Source Plugin for GSTreamer
======================================

tsgigevsrc is a gstreamer source plugin for images acquired from
GigeVision devices supported by Teledyne DALSA's GigE-V Framework for Linux.

The self-extracting installer support the following commands:

    ./tdgigevsrc_installer.run  [options] [--] [args]
        --help, -h, ?   Print help info (this) and exit 
        --dryrun        Run setup script but do not copy the plugin to the installation directory
        --extract       Extract the package directory, do not run setup script
        --remove        Uninstall the plugin

Since the acquisition framework is only available on Linux platforms, the
makefile is straightfoward. It relies on the use of the 'pkg-config' command
to determine the installed gstreamer configuration so that the plugin can
be compiled against the gstreamer framework in the currently running system
and installed to the appropriate location.

The plugin performs dynamic loading of the GigE-V Framework detected at
run-time so that the framework can be updated without requiring the plugin 
be rebuilt and reinstalled.

The initial version of the plugin was done for gstreamer-1.0

The plugin supports the following parameters : 

    cam-index:     The index of the camera to select (as reported by lsgev)
    cam-sn:        The serial number (as a string) of the camera to select.
    cam-ip:        The ip address of the camera to select (as a string a:b:c:d)
    cam-name:      The "DeviceName" string (feature) of the camera to select 
    cfg-file:      A file of "FeatureName Value" pairs (1 per line) to apply to the camera. 
    bayer-as-mono: Provide bayer pixel formats as Mono (GRAY8/GRAY16) video.
    nfrm:          Number of internal frames to buffer in the GigE-V Framework.
	
(For more information, see the GigE-V Framework manual or enter
    "gst-inspect-1.0 tdgigevsrc" on the command line )

