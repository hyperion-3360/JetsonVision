// A simple demo grabbing images and showing frame reception and event statistics
#include "stdio.h"
#include "cordef.h"
#include "GenApi/GenApi.h"		//!< GenApi lib definitions.
#include "gevapi.h"				//!< GEV lib definitions.
#include <sched.h>

#define MAX_NETIF					8
#define MAX_CAMERAS_PER_NETIF	32
#define MAX_CAMERAS		(MAX_NETIF * MAX_CAMERAS_PER_NETIF)

// Enable/disable buffer FULL/EMPTY handling (cycling)
#define USE_SYNCHRONOUS_BUFFER_CYCLING	1

#define NUM_FRAMES				32
#define NUM_FRAMES_BUFFERED	8

typedef struct tagMY_CONTEXT
{
	GEV_CAMERA_HANDLE camHandle;
	uint64_t				frame_id;
	uint32_t				frame_count;
	uint32_t				frame_success_count;
	uint32_t				frame_timeout_count;
	uint32_t				frame_overflow_count;
	uint32_t				frame_bandwidth_count;
	uint32_t				frame_lost_count;
	uint32_t				frame_error;
	int					frame_error_value;
	uint32_t				missed_frame;
	uint32_t				current_frame_counter;
	uint64_t				last_block_id;
	uint32_t				event_count;
	uint32_t				event_id;
	uint64_t				event_timestamp;
	BOOL              exit;
}MY_CONTEXT, *PMY_CONTEXT;

int m_event_enabled = 0;

void PrintStatsHeader()
{
	if (m_event_enabled)
	{
		printf("\n frame_id : total#  : #valid  :  #err  :  frmstatus  : #skip :  events : evntID : evnttimestmp\n");
	}
	else
	{
		printf("\n frame_id : total#  : #valid  :  #err  :  frmstatus  : #skip\n");
	}
	return;
}
void PrintFrameStats( MY_CONTEXT *c, int errorFlag )
{
	const char *frame_err_str[] = { "    Ok     ", "  Pending  ", "  Timeout  ", "  Overflow ", "ResendLimit", " FrameLost ", "DeviceError"}; 
	if (c != NULL)
	{
		int index = (c->frame_error_value > 5) ? 5 : c->frame_error_value;
		uint32_t numerrors = c->frame_timeout_count + c->frame_overflow_count + c->frame_bandwidth_count + c->frame_lost_count + c->frame_error;

		if (m_event_enabled)
		{
			printf("  %7ld : %7d : %7d : %6d : %11s : %5d : %7d : 0x%04x : %lld", c->frame_id, c->frame_count, c->frame_success_count, \
					numerrors, frame_err_str[index], c->missed_frame, c->event_count, c->event_id, (long long unsigned int)c->event_timestamp);
		}
		else
		{
			printf("  %7ld : %7d : %7d : %6d : %11s : %5d", c->frame_id, c->frame_count, c->frame_success_count, \
					numerrors, frame_err_str[index], c->missed_frame);
		}
		
		if (errorFlag == 0)
		{
			printf("\r");
			fflush(stdout);
		}
		else
		{
			printf("\n");
		}	
	}
	return;
}

void CollectFrameStats( MY_CONTEXT *mycontext, GEV_BUFFER_OBJECT *img )
{
	int wraparound = 0;
	
	mycontext->frame_count += 1;
	mycontext->frame_error_value = img->status;
	if (img->status == 0)
	{
		// Track the frames received - make sure the id is incrementing properly
		mycontext->current_frame_counter++;
		if (img->id > mycontext->last_block_id)
		{
			wraparound = 0;
			if ( img->id != (mycontext->last_block_id + 1))
			{
				//missed_frame++;
				mycontext->missed_frame += img->id - (mycontext->last_block_id+1);
			}	
			mycontext->last_block_id = img->id;
		}	
		else
		{
			if ( (img->id > 1) && (mycontext->last_block_id > 65000) )
			{ 
				// Std 16-bit block id - wrapped.	
				// Wrap around 
				if (wraparound == 0)
				{
					wraparound = 1;
					if (img->id  > 1)
					{ 
						// Missed frame(s) at wraparound....
						mycontext->missed_frame += img->id - (65536 - mycontext->last_block_id);
					}	
				}	
				else
				{
					//missed_frame++;
					mycontext->missed_frame += img->id - mycontext->last_block_id;
				}
				mycontext->last_block_id = img->id;	
			}
			else
			{
				// Either extID or frame out-of-order 
				if (img->id < mycontext->last_block_id)
				{
					// Frame out of order (not supposed to happen)
					// (Fix up m issing frame count - not missing now)
					mycontext->missed_frame -= mycontext->last_block_id - img->id;
					mycontext->last_block_id = img->id;	
				}
				else
				{
					mycontext->missed_frame += img->id - mycontext->last_block_id;
					mycontext->last_block_id = img->id;	
				}
			}				
		}
		// Collect info
		mycontext->frame_success_count = mycontext->current_frame_counter;
		mycontext->frame_id = img->id;
				
		PrintFrameStats( mycontext, 0 );
	}	
	else
	{
		if ( img->status == 2 )
			mycontext->frame_timeout_count++;
		else if ( img->status == 3 )
			mycontext->frame_overflow_count++;
		else if ( img->status == 4 )
			mycontext->frame_bandwidth_count++;
		else if ( img->status == 5 )
			mycontext->frame_lost_count++;
		else
			mycontext->frame_error++;

		PrintFrameStats( mycontext, 1 );
	}	
}


int IsTurboDriveAvailable(GEV_CAMERA_HANDLE handle)
{
	int type;
	UINT32 val = 0;
	
	if ( 0 == GevGetFeatureValue( handle, "transferTurboCurrentlyAbailable",  &type, sizeof(UINT32), &val) )
	{
		// Current / Standard method present - this feature indicates if TurboMode is available.
		// (Yes - it is spelled that odd way on purpose).
		return (val != 0);
	}
	else
	{
		// Legacy mode check - standard feature is not there try it manually.
		char pxlfmt_str[64] = {0};

		// Mandatory feature (always present).
		GevGetFeatureValueAsString( handle, "PixelFormat", &type, sizeof(pxlfmt_str), pxlfmt_str);

		// Set the "turbo" capability selector for this format.
		if ( 0 != GevSetFeatureValueAsString( handle, "transferTurboCapabilitySelector", pxlfmt_str) )
		{
			// Either the capability selector is not present or the pixel format is not part of the 
			// capability set.
			// Either way - TurboMode is NOT AVAILABLE.....
			return 0; 
		}
		else
		{
			// The capabilty set exists so TurboMode is AVAILABLE.
			// It is up to the camera to send TurboMode data if it can - so we let it.
			return 1;
		}
	}
	return 0;
}

int GetNumber()
{
	char input[MAX_PATH] = {0};
	char *nptr = NULL;
	int num;

	scanf("%s", input);
	num = (int) strtol(input, &nptr, 10);

	if (nptr == input )
	{
		return -2;
	}
	return num;
}

int GetPixelFormatSelection(GEV_CAMERA_HANDLE handle, int size, char *pixelFormatString)
{
	int status = -1;
	int count = 0;
	int type = 0;

	// Get the node map.
	GenApi::CNodeMapRef *Camera = static_cast<GenApi::CNodeMapRef*>(GevGetFeatureNodeMap(handle));
	if (Camera)
	{
		try 
		{
			// Access the PixelFormat (mandatory) enumeration
			GenApi::CEnumerationPtr ptrPixFormat = Camera->_GetNode("PixelFormat");
			GenApi::NodeList_t selection; 
			GenApi::StringList_t availableFormats; 
			ptrPixFormat->GetEntries( selection );
			
			// See if there is more than one possible format
			count = (int)selection.size();
			if (count == 1)
			{
				// Only one pixel format - this is it.
				status = GevGetFeatureValueAsString(handle, "PixelFormat", &type, size, pixelFormatString);
				return status;
			}
			else
			{
				// Multiple pixel formats available - Iterate to present them for selection.
				int numFormats = 0;
				int i = 0;
				int num = 0;
				int done = 0;
				for ( i = 0; i < count; i++ )
				{
					GenApi::CEnumEntryPtr entry( selection[i] );
					if ( (GenApi::NI != entry->GetAccessMode()) && ( GenApi::NA != entry->GetAccessMode()))
					{
						numFormats++;
						availableFormats.push_back(entry->GetSymbolic());
					}
				} 
							
				if ( numFormats > 1 )
				{
					while(!done)
					{
						printf("\n Multiple PixelFormats available - select one by index/id :\n");
						for ( i = 0; i < numFormats; i++ )
						{
							printf("    [%02d] = %s \n", i, (const char *)(availableFormats[i]));
						}
						printf("Enter index (0 to %d) :", (numFormats-1));
						fflush(stdout);
						num = GetNumber();
						if ((num >= 0) && (num < numFormats))
						{
							done = 1;
						}
						else
						{
							printf(" \t\t%d : <out of range> ",num);
						}
					}
				}
				else
				{
					num = 0;
					printf("\n Pixel format set to %s \n", (const char *)(availableFormats[num]));					
				} 		
				strncpy(pixelFormatString, (const char *)(availableFormats[num]), size);
				status = 0;
			}
		}
		CATCH_GENAPI_ERROR(status);		
	}
	return status;
}

int GetEventSelection(GEV_CAMERA_HANDLE handle, int size, char *eventName)
{
	int status = -1;
	int count = 0;
	int type = 0;

	// Get the node map.
	GenApi::CNodeMapRef *Camera = static_cast<GenApi::CNodeMapRef*>(GevGetFeatureNodeMap(handle));
	if (Camera)
	{
		try 
		{
			// Access the EventSelector (mandatory) enumeration
			GenApi::CEnumerationPtr ptrEvents = Camera->_GetNode("EventSelector");
			GenApi::NodeList_t selection; 
			GenApi::StringList_t availableEvents; 
			ptrEvents->GetEntries( selection );
			
			// See if there is more than one possible format
			count = (int)selection.size();
			if (count == 1)
			{
				// Only one event - this is it.
				status = GevGetFeatureValueAsString(handle, "EventSelector", &type, size, eventName);
				return status;
			}
			else
			{
				// Multiple events available - Iterate to present them for selection.
				int numFormats = 0;
				int i = 0;
				int num = 0;
				int done = 0;
				for ( i = 0; i < count; i++ )
				{
					GenApi::CEnumEntryPtr entry( selection[i] );
					if ( (GenApi::NI != entry->GetAccessMode()) && ( GenApi::NA != entry->GetAccessMode()))
					{
						numFormats++;
						availableEvents.push_back(entry->GetSymbolic());
					}
				} 
							
				if ( numFormats > 1 )
				{
					while(!done)
					{
						printf("\n Multiple Events available - select one by index/id :\n");
						for ( i = 0; i < numFormats; i++ )
						{
							printf("    [%02d] = %s \n", i, (const char *)(availableEvents[i]));
						}
						printf("Enter index (0 to %d) or -1 for none :", (numFormats-1));
						fflush(stdout);
						num = GetNumber();
						if ((num >= -1) && (num < numFormats))
						{
							done = 1;
						}
						else
						{
							printf(" \t\t%d : <out of range> ",num);
						}
					}
				}
				else
				{
					if ((count == 0) || (numFormats == 0))
					{
						num = -1;
					}
					else
					{
						num = 0;
						printf("\n Event set to %s \n", (const char *)(availableEvents[num]));
					}
				} 	
				if (num != -1)
				{	
					strncpy(eventName, (const char *)(availableEvents[num]), size);
				}
				status = 0;
			}
		}
		CATCH_GENAPI_ERROR(status);		
	}
	return status;
}

void eventCallbackFunc( PEVENT_MSG msg, PUINT8 data, UINT16 size, void *ctxt)
{
	MY_CONTEXT *context = (MY_CONTEXT *)ctxt;
	context->event_count += 1;
	context->event_id = (UINT32)msg->eventNumber;
	context->event_timestamp = (UINT64)msg->timestamp;
	
	PrintFrameStats( context, 0 );
}



char GetKey()
{
   char key = getchar();
   while ((key == '\r') || (key == '\n'))
   {
      key = getchar();
   }
   return key;
}

void PrintMenu()
{
   printf("GRAB CTL : [S]=stop, [1-9]=snap N, [G]=continuous, [A]=Abort\n");
   printf("MISC     : [Q]or[ESC]=end,         [T]=Toggle TurboMode (if available)\n");
}

void * ImageReceiveThread( void *context)
{
	MY_CONTEXT *mycontext = (MY_CONTEXT *)context;

	if (mycontext != NULL)
	{
		// While we are still running.
		while(!mycontext->exit)
		{
			GEV_BUFFER_OBJECT *img = NULL;
			GEV_STATUS status = 0;
	
			// Wait for images to be received
			status = GevWaitForNextImage(mycontext->camHandle, &img, 1000);

			if ((img != NULL) && (status == GEVLIB_OK))
			{
				CollectFrameStats( mycontext, img);
			}
			else
			{
				if ( status == GEVLIB_ERROR_NO_CAMERA )
				{
					printf(" ** Camera Disconnected - 'q' to exit **\n");
				}
			}
#if USE_SYNCHRONOUS_BUFFER_CYCLING
			if (img != NULL)
			{
				// Release the buffer back to the image transfer process.
				GevReleaseImage( mycontext->camHandle, img);
			}
#endif
		}
	}
	pthread_exit(0);	
}


int main(int argc, char* argv[])
{
	GEV_DEVICE_INTERFACE  pCamera[MAX_CAMERAS] = {0};
	GEV_STATUS status;
	int numCamera = 0;
	int camIndex = 0;
	MY_CONTEXT context = {0};
   pthread_t  tid;
	char c;
	int done = FALSE;
	int turboDriveAvailable = 0;

	// Boost application RT response if needed.
	// GEV library already boosts data receive thread(s) internally)
	// SCHED_FIFO can cause many unintentional side effects.
	// SCHED_RR has fewer side effects.
	// SCHED_OTHER (normal default scheduler) is not too bad afer all.
	if (0)
	{
		//int policy = SCHED_FIFO;
		int policy = SCHED_RR;
		pthread_attr_t attrib;
		int inherit_sched = 0;
		struct sched_param param = {0};

		// Set an average RT priority (increase/decrease to tune performance).
		param.sched_priority = sched_get_priority_min(policy) + (sched_get_priority_max(policy) - sched_get_priority_min(policy)) / 2;
		
		// Set scheduler policy
		pthread_setschedparam( pthread_self(), policy, &param); // Don't care if it fails since we can't do anyting about it.
		
		// Make sure all subsequent threads use the same policy.
		pthread_attr_init(&attrib);
		pthread_attr_getinheritsched( &attrib, &inherit_sched);
		if (inherit_sched != PTHREAD_INHERIT_SCHED)
		{
			inherit_sched = PTHREAD_INHERIT_SCHED;
			pthread_attr_setinheritsched(&attrib, inherit_sched);
		}
	}

	//============================================================================
	// Greetings
	printf ("\nGigE Vision Library Simple C++ Example Program (%s)\n", __DATE__);

	//===================================================================================
	// Set default options for the library.
	{
		GEVLIB_CONFIG_OPTIONS options = {0};

		GevGetLibraryConfigOptions( &options);
		//options.logLevel = GEV_LOG_LEVEL_OFF;
		//options.logLevel = GEV_LOG_LEVEL_TRACE;
		options.logLevel = GEV_LOG_LEVEL_NORMAL;
		GevSetLibraryConfigOptions( &options);
	}

	//====================================================================================
	// DISCOVER Cameras
	//
	// Get all the IP addresses of attached network cards.

	status = GevGetCameraList( pCamera, MAX_CAMERAS, &numCamera);

	printf ("%d camera(s) on the network\n", numCamera);

	// Select the first camera found (unless the command line has a parameter = the camera index)
	if (numCamera != 0)
	{
		if (argc > 1)
		{
			sscanf(argv[1], "%d", &camIndex);
			if (camIndex >= (int)numCamera)
			{
				printf("Camera index out of range - only %d camera(s) are present\n", numCamera);
				camIndex = -1;
			}
		}

		if (camIndex != -1)
		{
			//====================================================================
			// Connect to Camera
			//
			// Direct instantiation of GenICam XML-based feature node map.
			int i;
			int type;
			UINT32 height = 0;
			UINT32 width = 0;
			UINT32 format = 0;
			UINT32 depth = 2;
			UINT64 size;
			UINT64 payload_size;
			int numBuffers = NUM_FRAMES;
			PUINT8 bufAddress[NUM_FRAMES];
			int numFramesBuffered = NUM_FRAMES_BUFFERED;
			GEV_CAMERA_HANDLE handle = NULL;
			UINT32 convertedGevFormat = 0;
			UINT32 frame_timeout_ms;
			
			//====================================================================
			// Open the camera.
			status = GevOpenCamera( &pCamera[camIndex], GevControlMode, &handle);
			if (status == 0)
			{
				GEV_CAMERA_OPTIONS camOptions = {0};
								
				// If there are multiple pixel formats supported on this camera, get one.
				{
					char feature_name[MAX_GEVSTRING_LENGTH] =  {0};
					GetPixelFormatSelection( handle, sizeof(feature_name), feature_name);
					if ( GevSetFeatureValueAsString(handle, "PixelFormat", feature_name) == 0)
					{
						printf("\n\tUsing selected PixelFormat = %s\n\n", feature_name);
					}				
				}
	
				// Select an asynchronous event for notification (if desired).
				{
					char feature_name[MAX_GEVSTRING_LENGTH] =  {0};
					GetEventSelection( handle, sizeof(feature_name), feature_name);
					if ( GevSetFeatureValueAsString(handle, "EventSelector", feature_name) == 0)
					{
						char event_feature_name[MAX_GEVSTRING_LENGTH+8] =  {0};
						UINT32 eventIDValue = 0;
						int type = 0;
						//
						// GenICam SFNC states to prefix the selected event name 
						// with the string "Event" in order to retrieve the value
						// of the event ID to associate with the per ID callback.
						//
						strncat(event_feature_name, "Event", sizeof(feature_name));
						strncat(event_feature_name, feature_name, sizeof(event_feature_name));
						status = GevGetFeatureValue( handle, event_feature_name, &type, sizeof(UINT32), &eventIDValue);
						if (status == 0)
						{
							GevSetFeatureValueAsString(handle, "EventNotification", "On");
							GevRegisterEventCallback(handle, eventIDValue, eventCallbackFunc, &context);
							printf("\n\tUsing selected Event = %s, ID = 0x%x\n\n", feature_name, eventIDValue);
							m_event_enabled = 1;
						}
						else
						{
							m_event_enabled = 0;
						}
						
					}		
				}
	
				// Get the frame payload parameters and image dimensions.
				GevGetPayloadParameters( handle,  &payload_size, &format);
				GevGetFeatureValue(handle, "Width", &type, sizeof(width), &width);
				GevGetFeatureValue(handle, "Height", &type, sizeof(height), &height);

				// Adjust internal buffering and timing for frames.
				numFramesBuffered = (numFramesBuffered > numBuffers) ? numBuffers : numFramesBuffered;
				{
					float frame_time_ms = ((float)payload_size/100000000.0) * 1000.0; // Conservative estimate (using 100MB/s instead of theoretical 120MB/s)
					//printf("frame time = %f\n", frame_time_ms );
					frame_timeout_ms = (numFramesBuffered - 1) * frame_time_ms; 
				}

				// Adjust the camera interface options if desired (see the manual)
				GevGetCameraInterfaceOptions( handle, &camOptions);
				//camOptions.heartbeat_timeout_ms = 60000;		// For debugging (delay camera timeout while in debugger)
				camOptions.heartbeat_timeout_ms = 5000;			// Disconnect detection (5 seconds)
				camOptions.streamFrame_timeout_ms = 10*frame_timeout_ms;		// Internal timeout for frame reception.
				camOptions.streamNumFramesBuffered = numFramesBuffered;	// Buffer frames internally.

				camOptions.streamMemoryLimitMax = (UINT32) ((UINT64)numFramesBuffered * payload_size); // Adjust packet memory buffering limit.	

				// Write the adjusted interface options back.
				GevSetCameraInterfaceOptions( handle, &camOptions);

				// Allocate image buffers
				// Either the image size or the payload_size, whichever is larger 
				// (This allows for packed pixel formats)
				depth = GetPixelSizeInBytes(GevGetUnpackedPixelType(format));
				size = depth * width * height;
				size = (payload_size > size) ? payload_size : size;
				for (i = 0; i < numBuffers; i++)
				{
					bufAddress[i] = (PUINT8)malloc(size);
					memset(bufAddress[i], 0, size);
				}
					
#if USE_SYNCHRONOUS_BUFFER_CYCLING
				// Initialize a transfer with synchronous buffer handling.
				status = GevInitializeTransfer( handle, SynchronousNextEmpty, size, numBuffers, bufAddress);
#else
				// Initialize a transfer with asynchronous buffer handling.
				status = GevInitializeTransfer( handle, Asynchronous, size, numBuffers, bufAddress);
#endif

				// Get the pixel format provided following image reception. 
				// (Packed pixels are unpacked internally unless passthru mode is enabled).
				convertedGevFormat = GevGetConvertedPixelType( FALSE, format);

				if (format != convertedGevFormat) 
				{
					printf("Input pixel format 0x%x will be converted automatically to 0x%x\n", format, convertedGevFormat);
				}

				// Create a thread for receiving images.
				context.camHandle = handle;
				context.exit = FALSE;
		   	pthread_create(&tid, NULL, ImageReceiveThread, &context); 
					
	         // Call the main command loop or the example.
	         PrintMenu();
	         while(!done)
	         {
	            c = GetKey();
	            // Toggle turboMode
	            if ((c == 'T') || (c=='t'))
	            {
						// See if TurboDrive is available.
						turboDriveAvailable = IsTurboDriveAvailable(handle);
						if (turboDriveAvailable)
						{
							UINT32 val = 1;
							GevGetFeatureValue(handle, "transferTurboMode", &type, sizeof(UINT32), &val);
							val = (val == 0) ? 1 : 0;
							GevSetFeatureValue(handle, "transferTurboMode", sizeof(UINT32), &val);
							GevGetFeatureValue(handle, "transferTurboMode", &type, sizeof(UINT32), &val);
							if (val == 1)
							{
								printf("TurboMode Enabled\n"); 	
							}
							else
							{
								printf("TurboMode Disabled\n"); 	
							}														
						}
						else
						{
							printf("*** TurboDrive is NOT Available for this device/pixel format combination ***\n");
						}
	            }
		            
	            // Stop
	            if ((c == 'S') || (c=='s') || (c == '0'))
	            {
						GevStopTransfer(handle);
	            }
	            //Abort
	            if ((c == 'A') || (c=='a'))
	            {
 						GevAbortTransfer(handle);
					}
	            // Snap N (1 to 9 frames)
	            if ((c >= '1')&&(c<='9'))
	            {
						for (i = 0; i < numBuffers; i++)
						{
							memset(bufAddress[i], 0, size);
						}
						PrintStatsHeader();
						status = GevStartTransfer( handle, (UINT32)(c-'0'));
						if (status != 0) 
						{
							printf("Error starting grab - 0x%x  or %d\n", status, status); 
						}
					}
	            // Continuous grab.
	            if ((c == 'G') || (c=='g'))
	            {
						for (i = 0; i < numBuffers; i++)
						{
							memset(bufAddress[i], 0, size);
						}
 						PrintStatsHeader();
						status = GevStartTransfer( handle, -1);
						if (status != 0) 
						{
							printf("Error starting grab - 0x%x  or %d\n", status, status); 
						}
	            }
					
	            if (c == '?')
	            {
	               PrintMenu();
	            }

	            if ((c == 0x1b) || (c == 'q') || (c == 'Q'))
	            {
						GevStopTransfer(handle);
	               done = TRUE;
						context.exit = TRUE;
	   				pthread_join( tid, NULL);      
	            }
	         }

				GevAbortTransfer(handle);
				status = GevFreeTransfer(handle);

				for (i = 0; i < numBuffers; i++)
				{	
					free(bufAddress[i]);
				}
			}
			GevCloseCamera(&handle);
			printf("\n");
		}
		else
		{
			printf("Error : 0x%0x : opening camera\n", status);
		}
	}

	// Close down the API.
	GevApiUninitialize();
	return 0;
}

