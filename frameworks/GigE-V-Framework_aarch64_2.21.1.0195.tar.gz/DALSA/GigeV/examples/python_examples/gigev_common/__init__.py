import enum
import ctypes


