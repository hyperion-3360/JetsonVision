Python Dependencies for examples 
---------------------------------

Python 3
--------

sudo apt-get install python3-tk
sudo apt-get install python3-pil.imagetk


Python 2.7
----------

sudo apt-get install python-pil.imagetk



Notes:
------

If enum is not installed by default....
try

"pip install enum34 --user"

or 

"pip install --upgrade pip enum34"



