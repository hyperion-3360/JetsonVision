//
// featuretree: Output the tree of all features accessible from the "Root" node.
//

#include "stdio.h"
#include "cordef.h"
#include "GenApi/GenApi.h"		//!< GenApi lib definitions.
#include "gevapi.h"				//!< GEV lib definitions.
//#include "SapX11Util.h"
//#include "X_Display_utils.h"
//#include <sched.h>

using namespace std;
using namespace GenICam;
using namespace GenApi;

#define MAX_NETIF					8
#define MAX_CAMERAS_PER_NETIF	32
#define MAX_CAMERAS		(MAX_NETIF * MAX_CAMERAS_PER_NETIF)

const char *intfTypeStrings[] = 
{
	"IValue", "IBase", "IInteger", "IBoolean", "ICommand", "IFloat", "IString",
	"IRegister", "ICategory", "IEnumeration", "IEnumEntry", "IPort"
};

static void DumpFeatureHierarchy( const CNodePtr &ptrFeature, int Indent )
{
	static int exception_count = 1;
   int i = 0;
   for (i = 0; i < Indent; i++)
   {
      printf("\t");
	}
    
   CCategoryPtr ptrCategory(ptrFeature);
   if( ptrCategory.IsValid() )
   {
       //cout << IndentStr << "Category '" << ptrFeature->GetName() << "'\n";
       printf("Category : %s\n", static_cast<const char *>(ptrFeature->GetName()));
       GenApi::FeatureList_t Features;
       ptrCategory->GetFeatures(Features);
       for( GenApi::FeatureList_t::iterator itFeature=Features.begin(); itFeature!=Features.end(); itFeature++ )
       {
          try {
             DumpFeatureHierarchy( (*itFeature), Indent + 2 );
             continue;
          }
          catch (...)
          {
             printf("Exception # %d reading feature pointer in category %s: \n", exception_count, static_cast<const char *>(ptrFeature->GetName()));
             exception_count++;             
			 }
       }
   }
   else
   {
		// Get the type of the feature as information.
		int index = static_cast<int>(ptrFeature->GetPrincipalInterfaceType());
		if ( (index >= (int)intfIValue) && (index <= (int)intfIPort))
		{	
			if ( (GenApi::RO == ptrFeature->GetAccessMode()	) || (GenApi::RW == ptrFeature->GetAccessMode())) 
			{
				// Readable feature (that is not a binary register).
            if ( index != 7 )
            {
				   CValuePtr valNode(ptrFeature);  
				   int len = strnlen( static_cast<const char *>(valNode->ToString()), 65);
				   if (len == 65 )
				   {
					   printf("%s : <%s> : value = <string too long> \n", static_cast<const char *>(ptrFeature->GetName()), intfTypeStrings[index]);
				   }
				   else
				   {
					   printf("%s : <%s> : value = %s\n", static_cast<const char *>(ptrFeature->GetName()), intfTypeStrings[index], static_cast<const char *>(valNode->ToString()) );					
   			   }
				}
				else
				{
					printf("%s : <%s> : value = <unprintable binary data> \n", static_cast<const char *>(ptrFeature->GetName()), intfTypeStrings[index]);					
				}
			}
			else
			{
				printf("%s : <%s>\n", static_cast<const char *>(ptrFeature->GetName()), intfTypeStrings[index]);
			}
		}
		else
		{
			printf("%s : <Unknown Type>\n", static_cast<const char *>(ptrFeature->GetName()));
		}
	}
}


int main(int argc, char* argv[])
{
	GEV_DEVICE_INTERFACE  pCamera[MAX_CAMERAS] = {0};
	UINT16 status;
	int numCamera = 0;
	int camIndex = 0;
	
	// Greetings
	printf ("\nGigE Vision Library GenICam Feature Tree Dumper (%s)\n", __DATE__);

	//===================================================================================
	// Set default options for the library.
	{
		GEVLIB_CONFIG_OPTIONS options = {0};

		GevGetLibraryConfigOptions( &options);
		//options.logLevel = GEV_LOG_LEVEL_OFF;
		//options.logLevel = GEV_LOG_LEVEL_TRACE;
		options.logLevel = GEV_LOG_LEVEL_NORMAL;
		GevSetLibraryConfigOptions( &options);
	}

	//====================================================================================
	// DISCOVER Cameras
	//
	// Get all the IP addresses of attached network cards.

	status = GevGetCameraList( pCamera, MAX_CAMERAS, &numCamera);

	printf ("%d camera(s) on the network\n", numCamera);

	// Select the first camera found (unless the command line has a parameter = the camera index)
	if (numCamera != 0)
	{
		// Extract the camera index (if present)
		if (argc > 1)
		{
			sscanf(argv[1], "%d", &camIndex);
			if (camIndex >= (int)numCamera)
			{
				printf("Camera index out of range - only %d camera(s) are present\n", numCamera);
				camIndex = -1;
			}
		}

		if (camIndex != -1)
		{
			//====================================================================
			// Connect to Camera
			//
			//
			GEV_CAMERA_HANDLE handle = NULL;

			// Open the camera.
			status = GevOpenCamera( &pCamera[camIndex], GevExclusiveMode, &handle);
			if (status == 0)
			{
				//=====================================================================
				// Get the GenICam FeatureNodeMap object and access the camera features.
				GenApi::CNodeMapRef *Camera = static_cast<GenApi::CNodeMapRef*>(GevGetFeatureNodeMap(handle));

				// Traverse the node map and dump all the features.
				if ( status == 0 )
				{
					// Find the standard "Root" node and dump the features.
					GenApi::CNodePtr pRoot = Camera->_GetNode("Root");
					printf("Dumping feature tree : \n");
					DumpFeatureHierarchy( pRoot, 1);
				}
				GevCloseCamera(&handle);
			}
			else
			{
				printf("Error : 0x%0x : opening camera\n", status);
			}
		}
	}

	// Close down the API.
	GevApiUninitialize();

	// Close socket API
	_CloseSocketAPI ();	// must close API even on error


	//printf("Hit any key to exit\n");
	//kbhit();

	return 0;
}

