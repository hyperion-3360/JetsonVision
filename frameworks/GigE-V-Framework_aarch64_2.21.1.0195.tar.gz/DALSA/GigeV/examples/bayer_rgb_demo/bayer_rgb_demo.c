
#include "stdio.h"
#include "cordef.h"
#include "gevapi.h"				//!< GEV lib definitions.
#include "SapX11Util.h"
#include "X_Display_utils.h"
#include "FileUtil.h"
#include <sched.h>
#include <sys/resource.h>
#include "thpool.h"


#define MAX_NETIF					8
#define MAX_CAMERAS_PER_NETIF	32
#define MAX_CAMERAS		(MAX_NETIF * MAX_CAMERAS_PER_NETIF)

#define ENABLE_DISPLAY 0
#if defined(LIBTIFF_AVAILABLE)
	#define ENABLE_SAVE_TO_TIF 1
#else
	#define ENABLE_SAVE_TO_TIF 0
#endif


// Enable/disable Bayer to RGB conversion
// (If disabled - Bayer format will be treated as Monochrome).
#define ENABLE_BAYER_CONVERSION      1
#define BAYER_CONVERSION_GPU         0
#define BAYER_CONVERSION_IN_PARALLEL 1

// Number of processing threads 
// Must be an EVEN number for bayer format (line pairs) 
#define NUM_PROCESSING_THREADS      4

// Enable/disable buffer FULL/EMPTY handling (cycling)
#define USE_SYNCHRONOUS_BUFFER_CYCLING	1

// Enable/disable transfer tuning (buffering, timeouts, thread affinity).
#define TUNE_STREAMING_THREADS 0

#define NUM_BUF	32
void *m_latestBuffer = NULL;

typedef struct tagMY_CONTEXT
{
   X_VIEW_HANDLE     View;
	GEV_CAMERA_HANDLE camHandle;
	int				depth;
	int 			format;
	void 			*convertBuffer;
	BOOL			convertFormat;
	uint64_t		frame_id;
	uint32_t		frame_count;
	uint32_t		frame_success_count;
	uint32_t		frame_timeout_count;
	uint32_t		frame_overflow_count;
	uint32_t		frame_bandwidth_count;
	uint32_t		frame_lost_count;
	uint32_t		frame_error;
	int				frame_error_value;
	uint32_t		missed_frame;
	uint32_t		current_frame_counter;
	uint64_t 		last_block_id;
	uint32_t        decode_time_us;
	int 			enable_sequence;
	int 			enable_save;
	void 			*saveBuffer;
	BOOL            exit;
}MY_CONTEXT, *PMY_CONTEXT;

typedef struct tagPROCESSING_CONTEXT
{	
	uint32_t height;
	uint32_t width;
	uint32_t in_depth;
	uint32_t in_format;
	void  *in_address;
	uint32_t out_depth;
	uint32_t out_format;
	void  *out_address;	
} PROCESSING_CONTEXT;


void _ConvertToRGB( void *context )
{
	PROCESSING_CONTEXT *pctx = (PROCESSING_CONTEXT *)context;

	if (pctx != NULL)
	{
	#if 0
		ConvertGevImageToX11Format( pctx->width, pctx->height, pctx->in_depth, pctx->in_format, pctx->in_address, \
								pctx->out_depth, pctx->out_format, pctx->out_address);
	#else
		// Convert the Bayer to RGB	
		int count      = GevGetPixelComponentCount(pctx->out_format);
		int d          = GevGetPixelDepthInBits(pctx->out_format);
		uint32_t size  = pctx->width * pctx->height * count * ((d + 7)/8);
		if (pctx->out_address != NULL)
		{
			unsigned char fill = (count == 4) ? 0xFF : 0;  // Alpha if needed.
			memset( pctx->out_address, fill, size);
			
		}
		ConvertBayerToRGB( 0, pctx->height, pctx->width, pctx->in_format, pctx->in_address, \
							  pctx->out_format, pctx->out_address);
	#endif							
	}
}




static unsigned long us_timer_init( void )
{
   struct timeval tm;
   unsigned long msec;
   
   // Get the time and turn it into a millisecond counter.
   gettimeofday( &tm, NULL);
   
   msec = (tm.tv_sec * 1000000) + (tm.tv_usec);
   return msec;
}
static unsigned long ms_timer_init( void )
{
   struct timeval tm;
   unsigned long msec;
   
   // Get the time and turn it into a millisecond counter.
   gettimeofday( &tm, NULL);
   
   msec = (tm.tv_sec * 1000) + (tm.tv_usec / 1000);
   return msec;
}

static int ms_timer_interval_elapsed( unsigned long origin, unsigned long timeout)
{
   struct timeval tm;
   unsigned long msec;
   
   // Get the time and turn it into a millisecond counter.
   gettimeofday( &tm, NULL);
   
   msec = (tm.tv_sec * 1000) + (tm.tv_usec / 1000);
      
   // Check if the timeout has expired.
   if ( msec > origin )
   {
      return ((msec - origin) >= timeout) ? TRUE : FALSE;
   }
   else
   {
      return ((origin - msec) >= timeout) ? TRUE : FALSE;
   }
}

static void _GetUniqueFilename( char *filename, size_t size, char *basename)
{
	// Create a filename based on the current time (to 0.01 seconds)
	struct timeval tm;
	uint32_t years, days, hours, seconds;

	if ((filename != NULL) && (basename != NULL) )
	{
		if (size > (16 + sizeof(basename)) )
		{
	
			// Get the time and turn it into a 10 msec resolution counter to use as an index.
			gettimeofday( &tm, NULL);
			years = ((tm.tv_sec / 86400) / 365);
			tm.tv_sec = tm.tv_sec - (years*86400*365);
			days  = (tm.tv_sec / 86400);
			tm.tv_sec = tm.tv_sec - (days * 86400);
			hours = (tm.tv_sec / 3600);
			seconds = tm.tv_sec - (hours * 3600);						
															
			snprintf(filename, size, "%s_%03d%02d%04d%02d", basename, days,hours, (int)seconds, (int)(tm.tv_usec/10000));
		}
	}
}

static void _CreateUniqueFilename( char *filename, size_t size)
{
	if (filename != NULL )
	{
		// Create a filename based on the current time (to 0.01 seconds)
		time_t timetval;
		struct timeval tv;
		struct tm tm;
		uint32_t year, month, day, hour, minute, seconds;

		gettimeofday( &tv, NULL);

		timetval = (time_t) tv.tv_sec;
		localtime_r( &timetval, &tm);
		
		year    = tm.tm_year + 1900;
		month   = tm.tm_mon + 1;
		day     = tm.tm_mday;
		hour    = tm.tm_hour;
		minute  = tm.tm_min;
		seconds = tm.tm_sec;

		
		snprintf( filename, size, "%4hd%02hd%02hd_%02hd:%02hd:%02hd", \
			year, month, day, hour, minute, seconds);
	}
}

static void _CreateIndexedFilename( char *filename, size_t size, char *basename, int index )
{
	if ((filename != NULL) && (basename != NULL) )
	{
		int len = strlen(basename);
		if ( size > (len+4) )
		{
			strcpy(filename, basename);
			snprintf(&filename[len], (size - (len+4)), "_%03d", index);
		}
		else
		{
			snprintf(filename, size, "%03d_", index);
		}
		
	}
}

void PrintStatsHeader()
{
	printf("\n frame_id : total#  : #valid  :  #err  :  frmstatus  : #skipped : decode_time_us\n");
	return;
}
void PrintFrameStats( MY_CONTEXT *c, int errorFlag )
{
	const char *frame_err_str[] = { "    Ok     ", "  Pending  ", "  Timeout  ", "  Overflow ", "ResendLimit", " FrameLost ", "DeviceError"}; 
	if (c != NULL)
	{
		int index = (c->frame_error_value > 5) ? 5 : c->frame_error_value;
		uint32_t numerrors = c->frame_timeout_count + c->frame_overflow_count + c->frame_bandwidth_count + c->frame_lost_count + c->frame_error;

		printf("  %7ld : %7d : %7d : %6d : %11s : %8u : %u", c->frame_id, c->frame_count, c->frame_success_count, \
				numerrors, frame_err_str[index], c->missed_frame, c->decode_time_us);
		
		if (errorFlag == 0)
		{
			//printf("\n");
			printf("\r");
			fflush(stdout);
		}
		else
		{
			printf("\n");
		}	
	}
	return;
}

void CollectFrameStats( MY_CONTEXT *mycontext, GEV_BUFFER_OBJECT *img )
{
	int wraparound = 0;
	
	mycontext->frame_count += 1;
	mycontext->frame_error_value = img->status;
	if (img->status == 0)
	{
		// Track the frames received - make sure the id is incrementing properly
		mycontext->current_frame_counter++;
		if (img->id > mycontext->last_block_id)
		{
			wraparound = 0;
			if ( img->id != (mycontext->last_block_id + 1))
			{
				//missed_frame++;
				mycontext->missed_frame += img->id - (mycontext->last_block_id+1);
			}	
			mycontext->last_block_id = img->id;
		}	
		else
		{
			if ( (img->id > 1) && (mycontext->last_block_id > 65000) )
			{ 
				// Std 16-bit block id - wrapped.	
				// Wrap around 
				if (wraparound == 0)
				{
					wraparound = 1;
					if (img->id  > 1)
					{ 
						// Missed frame(s) at wraparound....
						mycontext->missed_frame += img->id - (65536 - mycontext->last_block_id);
					}	
				}	
				else
				{
					//missed_frame++;
					mycontext->missed_frame += img->id - mycontext->last_block_id;
				}
				mycontext->last_block_id = img->id;	
			}
			else
			{
				// Either extID or frame out-of-order 
				if (img->id < mycontext->last_block_id)
				{
					// Frame out of order (not supposed to happen)
					// (Fix up m issing frame count - not missing now)
					mycontext->missed_frame -= mycontext->last_block_id - img->id;
					mycontext->last_block_id = img->id;	
				}
				else
				{
					mycontext->missed_frame += img->id - mycontext->last_block_id;
					mycontext->last_block_id = img->id;	
				}
			}				
		}
		// Collect info
		mycontext->frame_success_count = mycontext->current_frame_counter;
		mycontext->frame_id = img->id;
				
		PrintFrameStats( mycontext, 0 );
	}	
	else
	{
		if ( img->status == 2 )
			mycontext->frame_timeout_count++;
		else if ( img->status == 3 )
			mycontext->frame_overflow_count++;
		else if ( img->status == 4 )
			mycontext->frame_bandwidth_count++;
		else if ( img->status == 5 )
			mycontext->frame_lost_count++;
		else
			mycontext->frame_error++;

		PrintFrameStats( mycontext, 1 );
	}	
}

char GetKey()
{
   char key = getchar();
   while ((key == '\r') || (key == '\n'))
   {
      key = getchar();
   }
   return key;
}

void PrintMenu()
{
   printf("GRAB CTL : [S]=stop, [1-9]=snap N, [G]=continuous, [A]=Abort\n");
   printf("SAVE CTL : [C]=Toggle Frame Sequence Capture To Files (On/Off)\n");
   printf("SAVE CTL : [@]=Save Last Image To File\n");
   printf("MISC     : [Q]or[ESC]=end,         [T]=Toggle TurboMode (if available), [@]=SaveToFile\n");
}

void * ImageDisplayThread( void *context)
{
	MY_CONTEXT *displayContext = (MY_CONTEXT *)context;

	if (displayContext != NULL)
	{
		unsigned long prev_time = 0;
		unsigned long cur_time = 0;
		threadpool thpool;
		PROCESSING_CONTEXT processingContext[NUM_PROCESSING_THREADS] = {0};
		int sequence_init = 0;
		char unique_filename[250] = {0};
		int  dir_length = 0;

		GevInitThreadRealtime();
		
		thpool = thpool_init(NUM_PROCESSING_THREADS);  // Parallelize by N.

	#if ENABLE_SAVE_TO_TIF
		{
			int ret = -1;
			// Output image file(s) in subdirectory "images"
			ret = mkdir( "./images", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
			if ( (ret == 0) || ((ret != 0) && (errno == EEXIST)) )
			{
				// Access directory "./images"
				strncpy(unique_filename, "./images/", sizeof(unique_filename));
				dir_length = strlen(unique_filename);
			}
		}
	#endif

		// While we are still running.
		while(!displayContext->exit)
		{
			GEV_BUFFER_OBJECT *img = NULL;
			GEV_STATUS status = 0;
			uint32_t save_as_format = 0;
			void *save_data_ptr = NULL;
	
			// Wait for images to be received
			status = GevWaitForNextImage(displayContext->camHandle, &img, 1000);

			if ((img != NULL) && (status == GEVLIB_OK))
			{
				CollectFrameStats( displayContext, img );
				if (img->status == 0)
				{
					m_latestBuffer = img->address;
					
					// Can the acquired buffer be displayed?
					if ( IsGevPixelTypeX11Displayable(img->format) || displayContext->convertFormat )
					{
						// Convert the image format if required.
						if (displayContext->convertFormat)
						{
							int gev_depth  = GevGetPixelDepthInBits(img->format);
							save_as_format = GevGetBayerAsRGBPixelType(img->format);  // Bayer will be converted to RGB.
							save_data_ptr  = displayContext->saveBuffer;
							prev_time = us_timer_init();
				#if !BAYER_CONVERSION_GPU
				
				   #if BAYER_CONVERSION_IN_PARALLEL
				   {
						int i = 0;
						int lines_per_strip = (img->h/NUM_PROCESSING_THREADS) & ~0x00ff;
						off_t in_offset = (img->w * (gev_depth/8)) * lines_per_strip;
						off_t out_offset = (img->w * (displayContext->depth/8)) * lines_per_strip;
						int last_strip = img->h - (NUM_PROCESSING_THREADS - 1)*lines_per_strip;
						
						for (i = 0; i < (NUM_PROCESSING_THREADS-1); i++)
						{
							
							processingContext[i].height = lines_per_strip;
							processingContext[i].width  = img->w;
							processingContext[i].in_depth = gev_depth;
							processingContext[i].in_format = img->format;
							processingContext[i].in_address = img->address + i*in_offset;
							processingContext[i].out_depth = displayContext->depth;
							processingContext[i].out_format = save_as_format;
							processingContext[i].out_address = save_data_ptr  + i*out_offset;	
							thpool_add_work( thpool, (void *)_ConvertToRGB, &processingContext[i]);
						}
						// Handle last strip.
						processingContext[i].height = last_strip;
						processingContext[i].width  = img->w;
						processingContext[i].in_depth = gev_depth;
						processingContext[i].in_format = img->format;
						processingContext[i].in_address = img->address + i*in_offset;
						processingContext[i].out_depth = displayContext->depth;
						processingContext[i].out_format = save_as_format;
						processingContext[i].out_address = save_data_ptr  + i*out_offset;	
						thpool_add_work( thpool, (void *)_ConvertToRGB, &processingContext[i]);
							
						// Wait for it to be done
						thpool_wait(thpool);
						
				   }
				 #endif
				   
				#else
				
				#endif
				
						cur_time = us_timer_init();
						displayContext->decode_time_us = cur_time - prev_time;
			
				
				#if ENABLE_DISPLAY
							// Convert the image to a displayable format.
							//(Note : Not all formats can be displayed properly at this time (planar, YUV*, 10/12 bit packed).
							ConvertGevImageToX11Format( img->w, img->h, gev_depth, img->format, img->address, \
													displayContext->depth, displayContext->format, displayContext->convertBuffer);
							// Display the image in the (supported) converted format. 
							Display_Image( displayContext->View, displayContext->depth, img->w, img->h, displayContext->convertBuffer );				
				#endif
						}
						else
						{
							save_as_format = img->format;
							save_data_ptr  = img->address;
				#if ENABLE_DISPLAY
							// Display the image in the (supported) received format. 
							Display_Image( displayContext->View, img->d,  img->w, img->h, img->address );
				#endif
						}
					}
					else
					{
						//printf("Not displayable\n");
					}
					
				#if ENABLE_SAVE_TO_TIF
					if ( (displayContext->enable_save == 1) && (displayContext->enable_sequence == 0) )
					{ 
						displayContext->enable_save = 0;
						if (save_data_ptr != NULL)
						{
							char filename[250] = {0};
							// Save the file as TIF
							// Write the (current) image to TIFF 
							_CreateUniqueFilename( &unique_filename[dir_length], sizeof(unique_filename)-dir_length);
							_CreateIndexedFilename( filename, sizeof(filename), unique_filename, (uint32_t)img->id);
							strcat(filename, ".tif");
					printf("%s\n", filename); //????		
							Write_GevImage_ToTIFF( filename, img->w, img->h, save_as_format, save_data_ptr);	
						}
						
					}
					if ( displayContext->enable_sequence == 1 )
					{ 
						if (sequence_init == 0)
						{
							sequence_init = 1;
							printf(" *** Sequence Started *** \n");
							_CreateUniqueFilename( &unique_filename[dir_length], sizeof(unique_filename)-dir_length);
						}
						
						if (save_data_ptr != NULL)
						{
							char filename[250] = {0};
							// Save the file as TIF
							// Write the (current) image to TIFF 
							_CreateIndexedFilename( filename, sizeof(filename), unique_filename, (uint32_t)img->id);
							strcat(filename, ".tif");
					//printf("%s  : %s\n", unique_filename, filename); //????		
							
							Write_GevImage_ToTIFF( filename, img->w, img->h, save_as_format, save_data_ptr);	
						}
						
					}
					if ( (displayContext->enable_sequence == 0) && (sequence_init == 1))
					{ 
						sequence_init = 0;
						printf(" *** Sequence Ended *** \n");
					}
				#endif

					
				}
				else
				{
					// Image had an error (incomplete (timeout/overflow/lost)).
					// Do any handling of this condition necessary.
				}
			}
#if USE_SYNCHRONOUS_BUFFER_CYCLING
			if (img != NULL)
			{
				// Release the buffer back to the image transfer process.
				GevReleaseImage( displayContext->camHandle, img);
			}
#endif
		}
		thpool_destroy(thpool);
	}
	pthread_exit(0);	
}


int IsTurboDriveAvailable(GEV_CAMERA_HANDLE handle)
{
	int type;
	UINT32 val = 0;
	
	if ( 0 == GevGetFeatureValue( handle, "transferTurboCurrentlyAbailable",  &type, sizeof(UINT32), &val) )
	{
		// Current / Standard method present - this feature indicates if TurboMode is available.
		// (Yes - it is spelled that odd way on purpose).
		return (val != 0);
	}
	else
	{
		// Legacy mode check - standard feature is not there try it manually.
		char pxlfmt_str[64] = {0};

		// Mandatory feature (always present).
		GevGetFeatureValueAsString( handle, "PixelFormat", &type, sizeof(pxlfmt_str), pxlfmt_str);

		// Set the "turbo" capability selector for this format.
		if ( 0 != GevSetFeatureValueAsString( handle, "transferTurboCapabilitySelector", pxlfmt_str) )
		{
			// Either the capability selector is not present or the pixel format is not part of the 
			// capability set.
			// Either way - TurboMode is NOT AVAILABLE.....
			return 0; 
		}
		else
		{
			// The capabilty set exists so TurboMode is AVAILABLE.
			// It is up to the camera to send TurboMode data if it can - so we let it.
			return 1;
		}
	}
	return 0;
}

int main(int argc, char* argv[])
{
	GEV_DEVICE_INTERFACE  pCamera[MAX_CAMERAS] = {0};
	GEV_STATUS status;
	int numCamera = 0;
	int camIndex = 0;
   X_VIEW_HANDLE  View = NULL;
	MY_CONTEXT context = {0};
   pthread_t  tid;
	char c;
	int done = FALSE;
	int turboDriveAvailable = 0;
	char uniqueName[128];
	uint32_t macLow = 0; // Low 32-bits of the mac address (for file naming).

	//============================================================================
	// Greetings
	printf ("\nGigE Vision Library GenICam C Example Program (%s)\n", __DATE__);

	//===================================================================================
	// Set default options for the library.
	{
		GEVLIB_CONFIG_OPTIONS options = {0};

		GevGetLibraryConfigOptions( &options);
		//options.logLevel = GEV_LOG_LEVEL_OFF;
		//options.logLevel = GEV_LOG_LEVEL_TRACE;
		options.logLevel = GEV_LOG_LEVEL_NORMAL;
		GevSetLibraryConfigOptions( &options);
	}

	//====================================================================================
	// DISCOVER Cameras
	//
	// Get all the IP addresses of attached network cards.

	status = GevGetCameraList( pCamera, MAX_CAMERAS, &numCamera);

	printf ("%d camera(s) on the network\n", numCamera);

	// Select the first camera found (unless the command line has a parameter = the camera index)
	if (numCamera != 0)
	{
		if (argc > 1)
		{
			sscanf(argv[1], "%d", &camIndex);
			if (camIndex >= (int)numCamera)
			{
				printf("Camera index out of range - only %d camera(s) are present\n", numCamera);
				camIndex = -1;
			}
		}

		if (camIndex != -1)
		{
			//====================================================================
			// Connect to Camera
			//
			// Direct instantiation of GenICam XML-based feature node map.
			int i;
			int type;
			UINT32 height = 0;
			UINT32 width = 0;
			UINT32 format = 0;
			UINT32 maxHeight = 1600;
			UINT32 maxWidth = 2048;
			UINT32 maxDepth = 2;
			UINT64 size;
			UINT64 payload_size;
			int numBuffers = NUM_BUF;
			PUINT8 bufAddress[NUM_BUF];
			GEV_CAMERA_HANDLE handle = NULL;
			UINT32 pixFormat = 0;
			UINT32 pixDepth = 0;
			UINT32 convertedGevFormat = 0;
			
			//====================================================================
			// Open the camera.
			status = GevOpenCamera( &pCamera[camIndex], GevControlMode, &handle);
			if (status == 0)
			{
				//=================================================================
				// GenICam feature access via Camera XML File enabled by "open"
				// 
				// Get the name of XML file name back (example only - in case you need it somewhere).
				//
				char xmlFileName[MAX_PATH] = {0};
				status = GevGetGenICamXML_FileName( handle, (int)sizeof(xmlFileName), xmlFileName);
				if (status == GEVLIB_OK)
				{
					printf("XML stored as %s\n", xmlFileName);
				}
				status = GEVLIB_OK;

				// Get the camera width, height, and pixel format
				GevGetFeatureValue(handle, "Width", &type, sizeof(width), &width);
				GevGetFeatureValue(handle, "Height", &type, sizeof(height), &height);
				GevGetFeatureValue(handle, "PixelFormat", &type, sizeof(format), &format);
				
			}
			// Get the low part of the MAC address (use it as part of a unique file name for saving images).
			// Generate a unique base name to be used for saving image files
			// based on the last 3 octets of the MAC address.
			macLow = pCamera[camIndex].macLow;
			macLow &= 0x00FFFFFF;
			snprintf(uniqueName, sizeof(uniqueName), "img_%06x", macLow); 
			
			
			// Go on to adjust some API related settings (for tuning / diagnostics / etc....).
			if ( status == 0 )
			{
				GEV_CAMERA_OPTIONS camOptions = {0};

				// Adjust the camera interface options if desired (see the manual)
				GevGetCameraInterfaceOptions( handle, &camOptions);
				//camOptions.heartbeat_timeout_ms = 60000;		// For debugging (delay camera timeout while in debugger)
				camOptions.heartbeat_timeout_ms = 5000;		// Disconnect detection (5 seconds)

#if TUNE_STREAMING_THREADS
				// Some tuning can be done here. (see the manual)
				camOptions.streamFrame_timeout_ms = 1001;				// Internal timeout for frame reception.
				camOptions.streamNumFramesBuffered = 8;				// Buffer frames internally.
				camOptions.streamMemoryLimitMax = 64*1024*1024;		// Adjust packet memory buffering limit.	
				//camOptions.streamPktSize = 9180;							// Adjust the GVSP packet size.
				//camOptions.streamPktDelay = 10;							// Add usecs between packets to pace arrival at NIC.
				
				// Assign specific CPUs to threads (affinity) - if required for better performance.
				{
					int numCpus = _GetNumCpus();
					if (numCpus > 1)
					{
						camOptions.streamThreadAffinity = numCpus-1;
						camOptions.serverThreadAffinity = numCpus-2;
					}
				}
#endif
				// Write the adjusted interface options back.
				GevSetCameraInterfaceOptions( handle, &camOptions);

				if (status == 0)
				{
					//=================================================================
					// Set up a grab/transfer from this camera
					//
					// Get the image / payload size (adjusting for any unpacking of packed pixels)
					GevGetPayloadParameters( handle,  &payload_size, (UINT32 *)&type);
					maxHeight = height;
					maxWidth = width;
					maxDepth = GetPixelSizeInBytes(GevGetUnpackedPixelType(format)); 

					// Allocate image buffers - (image size or payload_size, whichever is larger)
					size = maxDepth * maxWidth * maxHeight;
					size = (payload_size > size) ? payload_size : size;
					for (i = 0; i < numBuffers; i++)
					{
						bufAddress[i] = (PUINT8)malloc(size);
						memset(bufAddress[i], 0, size);
					}
					

#if USE_SYNCHRONOUS_BUFFER_CYCLING
					// Initialize a transfer with synchronous buffer handling.
					status = GevInitializeTransfer( handle, SynchronousNextEmpty, size, numBuffers, bufAddress);
#else
					// Initialize a transfer with asynchronous buffer handling.
					status = GevInitializeTransfer( handle, Asynchronous, size, numBuffers, bufAddress);
#endif

					// Create an image display window.
					// This works best for monochrome and RGB. The packed color formats (with Y, U, V, etc..) require 
					// conversion as do, if desired, Bayer formats.
					// (Packed pixels are unpacked internally unless passthru mode is enabled).

					// Translate the raw pixel format to one suitable for the (limited) Linux display routines.			

					status = GetX11DisplayablePixelFormat( ENABLE_BAYER_CONVERSION, format, &convertedGevFormat, &pixFormat);

					if (format != convertedGevFormat) 
					{
						// We MAY need to convert the data on the fly to display it.
						if (GevIsPixelTypeRGB(convertedGevFormat))
						{
							// Conversion to RGB888 required.
							pixDepth = 32;	// Assume 4 8bit components for color display (RGBA)
							context.format = Convert_SaperaFormat_To_X11( pixFormat);
							context.depth = pixDepth;
							context.convertBuffer = malloc((maxWidth * maxHeight * ((pixDepth + 7)/8)));
							context.convertFormat = TRUE;
							context.saveBuffer = malloc((maxWidth * maxHeight * ((pixDepth + 7)/8)));
						}
						else
						{
							// Converted format is MONO - generally this is handled
							// internally (unpacking etc...) unless in passthru mode.
							// (						
							pixDepth = GevGetPixelDepthInBits(convertedGevFormat);
							context.format = Convert_SaperaFormat_To_X11( pixFormat);
							context.depth = pixDepth;							
							context.convertBuffer = NULL;
							context.convertFormat = FALSE;
							context.saveBuffer = NULL;
						}
					}
					else
					{
						pixDepth = GevGetPixelDepthInBits(convertedGevFormat);
						context.format = Convert_SaperaFormat_To_X11( pixFormat);
						context.depth = pixDepth;
						context.convertBuffer = NULL;
						context.convertFormat = FALSE;
						context.saveBuffer = NULL;
					}
					
		#if ENABLE_DISPLAY
					View = CreateDisplayWindow("GigE-V GenApi Console Demo", TRUE, height, width, pixDepth, pixFormat, FALSE ); 
		#endif
					// Create a thread to receive images from the API and display them.
					context.View = View;
					context.camHandle = handle;
					context.exit = FALSE;
		   		pthread_create(&tid, NULL, ImageDisplayThread, &context); 

					
		         // Call the main command loop or the example.
		         PrintMenu();
		         while(!done)
		         {
		            c = GetKey();

		            // Toggle turboMode
		            if ((c == 'T') || (c=='t'))
		            {
							// See if TurboDrive is available.
							turboDriveAvailable = IsTurboDriveAvailable(handle);
							if (turboDriveAvailable)
							{
								UINT32 val = 1;
								GevGetFeatureValue(handle, "transferTurboMode", &type, sizeof(UINT32), &val);
								val = (val == 0) ? 1 : 0;
								GevSetFeatureValue(handle, "transferTurboMode", sizeof(UINT32), &val);
								GevGetFeatureValue(handle, "transferTurboMode", &type, sizeof(UINT32), &val);
								if (val == 1)
								{
									printf("TurboMode Enabled\n"); 	
								}
								else
								{
									printf("TurboMode Disabled\n"); 	
								}														
							}
							else
							{
								printf("*** TurboDrive is NOT Available for this device/pixel format combination ***\n");
							}
		            }
		            
		            // Stop
		            if ((c == 'S') || (c=='s') || (c == '0'))
		            {
							GevStopTransfer(handle);
		            }
		            //Abort
		            if ((c == 'A') || (c=='a'))
		            {
	 						GevAbortTransfer(handle);
						}
		            // Snap N (1 to 9 frames)
		            if ((c >= '1')&&(c<='9'))
		            {
							for (i = 0; i < numBuffers; i++)
							{
								memset(bufAddress[i], 0, size);
							}

							PrintStatsHeader();
							status = GevStartTransfer( handle, (UINT32)(c-'0'));
							if (status != 0) printf("Error starting grab - 0x%x  or %d\n", status, status); 
						}
		            // Continuous grab.
		            if ((c == 'G') || (c=='g'))
		            {
							for (i = 0; i < numBuffers; i++)
							{
								memset(bufAddress[i], 0, size);
							}
							PrintStatsHeader();
	 						status = GevStartTransfer( handle, -1);
							if (status != 0) printf("Error starting grab - 0x%x  or %d\n", status, status); 
		            }
					
		            // Save image
		            if ((c == '@'))
		            {
						#if ENABLE_SAVE_TO_TIF
							context.enable_save = 1;
						#else
							printf("Save To TIF not available - install libtiff-dev\n");
						#endif
		            }
		            // Save Sequence (toggle)
		            if ((c == 'C') || (c == 'c'))
		            {
						#if ENABLE_SAVE_TO_TIF
							if (context.enable_sequence == 0)
							{
								context.enable_sequence = 1;
							}
							else
							{
								context.enable_sequence = 0;
							}
						#else
							printf("Save To TIF not available - install libtiff-dev\n");
						#endif
		            }
		            // Save image
		            //if ((c == '@'))
		            if (0)
		            {
							char filename[256] = {0};
							int ret = -1;
							uint32_t saveFormat = format;
							void *bufToSave = m_latestBuffer;
							int allocate_conversion_buffer = 0;
							
							// Make sure we have data to save.
							if ( m_latestBuffer != NULL )
							{
								uint32_t component_count = 1;
								UINT32 convertedFmt = 0;
								
								// Bayer conversion enabled for save image to file option.
								//
								// Get the converted pixel type received from the API that is 
								//	based on the pixel type output from the camera.
								// (Packed formats are automatically unpacked - unless in "passthru" mode.)
								//
								convertedFmt = GevGetConvertedPixelType( 0, format);
								
								if ( GevIsPixelTypeBayer( convertedFmt ) && ENABLE_BAYER_CONVERSION )
								{
									int img_size = 0;
									int img_depth = 0;
									uint8_t fill = 0;
									
									// Bayer will be converted to RGB.
									saveFormat = GevGetBayerAsRGBPixelType(convertedFmt);
									
									// Convert the image to RGB.
									img_depth = GevGetPixelDepthInBits(saveFormat);
									component_count = GevGetPixelComponentCount(saveFormat);
									img_size = width * height * component_count* ((img_depth + 7)/8);
									bufToSave = malloc(img_size);  
									fill = (component_count == 4) ? 0xFF : 0;  // Alpha if needed.
									memset( bufToSave, fill, img_size);
									allocate_conversion_buffer = 1;
									
									// Convert the Bayer to RGB	
									ConvertBayerToRGB( 0, height, width, convertedFmt, m_latestBuffer, saveFormat, bufToSave);

								}
								else								
								{
									saveFormat = convertedFmt;
									allocate_conversion_buffer = 0;
								}
								// Generate a file name from the unique base name.
								_GetUniqueFilename(filename, (sizeof(filename)-5), uniqueName);
								
#if defined(LIBTIFF_AVAILABLE)
								// Add the file extension we want.
								strncat( filename, ".tif", sizeof(filename));
								
								// Write the file (from the latest buffer acquired).
								ret = Write_GevImage_ToTIFF( filename, width, height, saveFormat, bufToSave);								
								if (ret > 0)
								{
									printf("Image saved as : %s : %d bytes written\n", filename, ret); 
								}
								else
								{
									printf("Error %d saving image\n", ret);
								}
#else
								printf("*** Library libtiff not installed ***\n");
#endif
							}
							else
							{
								printf("No image buffer has been acquired yet !\n");
							}
							
							// Quick test that the image can be read back.
					#if 1
							if (ret == 0)
							{
								uint32_t w, h;
								int d;
								int num_components = 0;
								int pxlsize = 0;
								void *rtif = NULL;
								uint32_t size;
								
#if defined(LIBTIFF_AVAILABLE)
								File_GetTIFFInfo( filename, &w, &h, &d, &num_components);
								//printf("TIFF Info : 1=%d, h=%d, d=%d, spp=%d\n", w,h,d,num_components);
								
								// Calculate the pixel size
								pxlsize = (num_components > 1) ? num_components : ((d+7)/8);
								size = w*h*pxlsize;

								rtif = malloc(size);
								if (rtif != NULL)
								{
									// Set up a suitable pixel format to read.
									uint32_t pxlFmt = fmtMono8;
									if ( num_components == 1 )
									{
										pxlFmt = (d > 8) ? fmtMono16 : fmtMono8;
									}
									else if (num_components == 3 )
									{
										pxlFmt = (d > 8) ? fmtRGB16Packed : fmtRGB8Packed;
									}
									else if (num_components == 4 )
									{
										pxlFmt = (d > 8) ? fmtRGBA16Packed : fmtRGBA8Packed;
									}
									else
									{
										printf("Error : Unexpected number of pixel components (%d)\n", num_components);
									}
									
									Read_TIFF_ToGevImage( filename,  &w, &h, pxlFmt, size, rtif);
																		
									{
										uint32_t i;
										unsigned char *orig, *rimg;
										orig = (unsigned char *)bufToSave;
										rimg = (unsigned char *)rtif;
										for (i = 0; i < size; i++)
										{
											if (orig[i] != rimg[i])
											{
												printf(" Mismatch : i = %d:\n", i);
												break;
											}
										}
									}
									free(rtif);
								}
#endif
							}
						#endif
						
							if (allocate_conversion_buffer)
							{
								free(bufToSave);
							}
						
		            }
		            if (c == '?')
		            {
		               PrintMenu();
		            }

		            if ((c == 0x1b) || (c == 'q') || (c == 'Q'))
		            {
							GevStopTransfer(handle);
		               done = TRUE;
							context.exit = TRUE;
		   				pthread_join( tid, NULL);      
		            }
		         }

					GevAbortTransfer(handle);
					status = GevFreeTransfer(handle);
				#if ENABLE_DISPLAY
					DestroyDisplayWindow(View);
				#endif


					for (i = 0; i < numBuffers; i++)
					{	
						free(bufAddress[i]);
					}
					if (context.convertBuffer != NULL)
					{
						free(context.convertBuffer);
						context.convertBuffer = NULL;
					}
					if (context.saveBuffer != NULL)
					{
						free(context.convertBuffer);
						context.saveBuffer = NULL;
					}
				}
				GevCloseCamera(&handle);
			}
			else
			{
				printf("Error : 0x%0x : opening camera\n", status);
			}
		}
	}

	// Close down the API.
	GevApiUninitialize();

	// Close socket API
	_CloseSocketAPI ();	// must close API even on error


	//printf("Hit any key to exit\n");
	//kbhit();

	return 0;
}

