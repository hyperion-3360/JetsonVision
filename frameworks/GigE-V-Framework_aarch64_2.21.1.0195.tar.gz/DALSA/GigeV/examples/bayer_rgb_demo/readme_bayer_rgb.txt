bayer_rgb_demo
=====================

The bayer_rgb_demo uses a thread pool to convert bayer to rgb 
in parallel so it can be completed before the next frame is received.

There a definitions in the source code to control what is executed:

ENABLE_BAYER_CONVERSION        : Have bayer converted to RGB  
BAYER_CONVERSION_IN_PARALLEL   : Use the thread pool.
BAYER_CONVERSION_GPU           : <future use when CUDA support is available>

NUM_PROCESSING_THREADS         : The number of threads to use 
                               : Must be an even number, should be less than #cpus.

NUM_BUF                        : Number of buffers to use.

USE_SYNCHRONOUS_BUFFER_CYCLING : Prevents acquisition from over-writing buffers 
                               : until buffer is released back to API.

ENABLE_DISPLAY                 : Enables image display (simple X11 window)
                               : (Keep frame rate low, bayer conversion to the 
                               :  displayable format is slow and "in-addition" to
                               :  bayer_rgb section (for now)).

Notes : 
   1) Saving to disk as tif files is enabled only if libtiff is available 
      (install the package libtiff-dev)
   2) The bayer to rgb conversion routine is a simple 2x2  implementation.
   3) The command "@" will save a single image to a tif file.
   4) The command "c" will start a sequence of images being saved, a subsequent
      command "c" will stop the sequence. Writing images to storage impacts the 
      performance.
