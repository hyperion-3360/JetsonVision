#ifndef _ASSERT_WITH_UNUSED_H
#define _ASSERT_WITH_UNUSED_H

#include <assert.h>

#define UNUSED(x) ((void)(x))

#endif
