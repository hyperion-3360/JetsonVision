Welcome to pytools's documentation!
===================================

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    reference
    obj_array
    persistent_dict
    graph
    tag
    codegen
    mpi
    misc
    🚀 Github <https://github.com/inducer/pytools>
    💾 Download Releases <https://pypi.python.org/pypi/pytools>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
